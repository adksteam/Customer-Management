import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import LoginComponent from './screens/LoginComponent'
import ListCustomersComponent from './screens/ListCustomersComponent'
import CustomerDetails from './screens/CustomerDetails'
import AddUpdateCustomer from './screens/AddUpdateCustomer.jsx'
import Empty from './Empty';


class AppRouter extends Component{
  render(){
    return(
        <>
            <Router>
             <Switch>
               <Route path="/addCustomer" exact={true} component={AddUpdateCustomer} />
               <Route path="/login" exact={true} component={LoginComponent} />
               <Route path="/home" exact={true} component={ListCustomersComponent} />
               <Route path="/updateCustomer/:id" exact={true} component={AddUpdateCustomer} />
               <Route path="/showCustomer/:id"exact={true} component={CustomerDetails} />
               <Route path="/empty" exact={true} component={Empty}/>
             </Switch>
           </Router>
        </>
    );
  }
}

export default AppRouter
