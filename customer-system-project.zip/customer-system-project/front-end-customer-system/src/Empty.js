import React, { Component } from 'react';
import emoji from './images/sad.jpg';
import './css/img.css';
import Utilities from './Utilities';
class Empty extends Component{
    constructor(props){
        super(props);
        this.state = {
            customers: [],
            message:null
        }
        this.addCustomerClicked = this.addCustomerClicked.bind(this)
        this.logOut = this.logOut.bind(this);
    }
    addCustomerClicked() {
        this.props.history.push(`/addCustomer`)
    }
    logOut(){
        this.props.history.push('/login')
      }
  
    render(){
        return(<div>
            <div className="row" id = "addBtnRow">
                      <button className="btn btn-primary" onClick={this.logOut}>{Utilities.logoutIcon()}{'  '}Logout</button>
                      <button className="btn btn-success" onClick={this.addCustomerClicked}>{Utilities.addIcon()}{'  '}Add</button>
                  </div>
            <div className="nothing">
                <p className="H">Nothing to Show !!</p>
                 <img className="emoji" src={emoji} alt="emoji"/>
            </div>
            </div>
        );
    }
}
export default Empty;